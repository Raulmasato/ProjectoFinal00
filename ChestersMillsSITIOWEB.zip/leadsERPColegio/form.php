<?php
if(isset($_POST['submit'])){
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $mensaje = $_POST['mensaje'];
    
    $to = "franquito2001gabriel@gmail.com";
    $subject = "Nuevo LEAD de: " . $nombre;
    $body = "Nombre: " . $nombre . "\n" . "Email: " . $email . "\n" . "Celular: " . $telefono . "\n" . "Mensaje:\n" . $mensaje;
    
    if(mail($to, $subject, $body)){
        
        header("Location: confirmacion.html");
    }
    else{
        echo "Hubo un error al enviar el mensaje. Por favor, intenta de nuevo más tarde.";
    }
}

?>